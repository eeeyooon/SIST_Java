package com.project.sports.admin.ticketing;

public class TicketingDetail {

	public static void ticketingDetail() {
		
		
		
	}
}
