package com.project.sports.admin.ticketing;

import java.util.Scanner;
import com.project.sports.admin.AdminOutput;
import com.project.sports.input.Schedule;
import com.project.sports.input.Ticketing;
import com.project.sports.input.User;
import com.project.sports.main.Data;
import com.project.sports.output.Output;

public class GameDetail {

	public static void gameDetail() {
		
		
		Scanner sc = new Scanner(System.in);
		boolean gameDetailFlag = true;
		int gameSeq = 0;
		int ticketingSeq = 0;

		while(gameDetailFlag) {	//예매 확인 - 경기 예매내역 상세보기를 눌렀을때
			
				
				AdminOutput.ticketListDetail(); //경기번호 고르라는 메세지와 입력창
				String input = sc.nextLine(); // 경기번호 입력받기
				
				boolean hasGame = false;
		
				for (Schedule s : Data.scheduleList) {
					
					if (input.equals(Integer.toString(s.getSeq()))) { //입력받은 경기번호와 같은 경기일정 출력
						gameSeq += 1;
						hasGame = true;
						System.out.println("번호\t\t경기\t\t\t   날짜\t   시간\t  경기장");
						System.out.printf("%d\t%-9s vs %-9s\t%-10tF %s %-12s\n", 
								gameSeq,
								s.getTeam1(),
								s.getTeam2(),
								s.getDate(),
								s.getTime(),
								s.getPlace());
					
					}
				}
				
				//그 경기일정을 예매한 사람 내역 출력
				//37, 35, 38, 29 경기
				
				for (Ticketing t : Data.ticketingList) {
					
					//[seq][이름][아이디][예매좌석]
					if (input.equals(Integer.toString(t.getScheduleSeq()))) {
						ticketingSeq += 1;
						
						String ticketId = t.getId(); //예매한 아이디 저장
						String ticketName = "";
						
						
						for (User u : Data.userList) {
							
							if (ticketId.equals(u.getId())) {
								
								ticketName = u.getName();
								
							}
							
						}
						
						System.out.println();
						System.out.println("번호\t 이름\t   아이디\t\t\t 예매좌석");
						System.out.printf("%d\t%s\t%-16s\t%s %s\n",
											ticketingSeq,
											ticketName,
											t.getId(),
											t.getBlock(),
											t.getSeatNum());
					
						Output.pause();
					}
					
				}
				
				
				if(input.equals("")){
					
					System.out.println("내용을 입력해주세요.");
					
				} else if(input.equals("0")) {
					
					Output.backMsg();
					gameDetailFlag = false;
					
				} else if (hasGame == false) { //입력한 경기번호와 일치하는 경기가 없는경우
					System.out.println("해당 경기가 존재하지 않습니다.");
				}
				
				
		
		}
		
		
		
		
	}
}
