package com.project.sports.admin;

public class Admin {

}
